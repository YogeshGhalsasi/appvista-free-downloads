APPVISTA – DAILY TASK TRACKER (FREE EDITION)
Version: 1.0

Thank you for downloading this free application from AppVista.in.

GET STARTED
1. Extract the ZIP file to a folder on your computer.
2. Open the file named index.html in Google Chrome, Microsoft Edge, Firefox, or another modern browser.
3. Add your tasks using the input box and press Enter or the send button.
4. Mark tasks complete using the circular tick control.
5. Use the date navigation to review previous days.
6. Select Export to download your task history as a CSV file.

IMPORTANT DATA AND PRIVACY NOTES
- This is a standalone browser-based application. It does not require an account or send your task list to AppVista.
- Tasks are stored locally in your browser's local storage on the device where you use the app.
- Your tasks are not automatically synchronised between devices or browsers.
- Clearing browser data, using private/incognito mode, or resetting the browser may remove locally stored tasks.
- Use Export regularly to keep a separate CSV copy of your task history.
- The CSV export is a spreadsheet-friendly copy of your tasks; it is not an automatic restore file.

SUPPORT
Website: https://appvista.in
Product: Daily Task Tracker – Free Edition

© AppVista. Free edition for personal use.
